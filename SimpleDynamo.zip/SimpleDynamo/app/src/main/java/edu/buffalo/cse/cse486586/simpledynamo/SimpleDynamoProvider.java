package edu.buffalo.cse.cse486586.simpledynamo;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Formatter;
import java.util.HashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Semaphore;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.telephony.TelephonyManager;
import android.util.Log;

import static android.content.ContentValues.TAG;

public class SimpleDynamoProvider extends ContentProvider {
	Context context;
	String myhash;
	int prevNode = 0;
	int nextNode = 0;
	String nexthash;
	String prevhash;
	private int joinPort = 5554;
	private int myPort = 0;
	static final int SERVER_PORT = 10000;
	Uri myUri = null;
	private int queryInitiatorPort = 0;
	private ArrayList<String> joinedNodesList = new ArrayList<String>();
	private HashMap<String, Integer> hashPortMap = new HashMap<String, Integer>();
	private ArrayList<String> hashKeyList = new ArrayList<String>();
	private ArrayList<Integer> orderedPorts = new ArrayList<Integer>();
	private boolean isReplica = false;
	private Semaphore threadAccess;

	@Override
	public int delete(Uri uri, String selection, String[] selectionArgs) {
		// TODO Auto-generated method stub
		String filename = selection;
		String hashedKey = null;

		try {
			hashedKey = genHash(filename);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}

		if(filename.equals("@")) {
			// return all local key values
			synchronized (filename) {
				String[] listKeys = context.fileList();
				try {
					threadAccess.acquire();
					for (String key : listKeys) {
						File file = context.getFileStreamPath(key);
						boolean isdeleted = file.delete();
						Log.i(TAG, "file deleted? " + isdeleted);
					}
					new ClientTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, "replicatedDelete#@#1", nextNode*2);
					threadAccess.release();
				} catch (Exception e) {
					Log.e(TAG, "Error reading all local files " + e);
				}
			}
		} else if(filename.equals("*")) {
			new ClientTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, "delete#*#"+queryInitiatorPort, nextNode*2);
			delete(myUri, "@", null);
		} else if (isReplica || (prevNode == myPort && nextNode == myPort) || (hashedKey.compareTo(myhash) < 0 && hashedKey.compareTo(prevhash) >= 0) || (prevhash.compareTo(myhash) > 0 && nexthash.compareTo(myhash) > 0 && (hashedKey.compareTo(prevhash) >= 0 || hashedKey.compareTo(myhash) < 0))) {
			synchronized (filename) {
				try {
					threadAccess.acquire();
					File file = context.getFileStreamPath(filename);
					boolean isdeleted = file.delete();
					if(!isReplica) {
						new ClientTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, "replicatedDelete#" + filename + "#1", nextNode*2);
					}
					isReplica = false;
					Log.i(TAG, "Stored in cursor and returned");
					threadAccess.release();
				} catch (Exception e) {
					Log.e(TAG, "File read failed");
				}
			}
		} else {
			new ClientTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, "delete#" + filename + "#"+queryInitiatorPort, nextNode*2);
		}

		return 0;
	}

	@Override
	public String getType(Uri uri) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Uri insert(Uri uri, ContentValues values) {
		// TODO Auto-generated method stub
		String filename = (String)values.get("key");
		String string = (String)values.get("value");
		String hashedKey = null;

		try {
			hashedKey = genHash(filename);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}

		if(isReplica || (prevNode == myPort && nextNode == myPort) || (hashedKey.compareTo(myhash) < 0 && hashedKey.compareTo(prevhash) >= 0) || (prevhash.compareTo(myhash) > 0 && nexthash.compareTo(myhash) > 0 && (hashedKey.compareTo(prevhash) >= 0 || hashedKey.compareTo(myhash) < 0))) {

			synchronized (values) {

				FileOutputStream outputStream;
				Log.i(TAG, "insert locally " + myPort);

				try {
					threadAccess.acquire();
					if(context == null) {
						context = getContext();
					}
					outputStream = context.openFileOutput(filename, Context.MODE_PRIVATE);
					outputStream.write(string.getBytes());
					outputStream.close();
					Log.i(TAG, "!isReplica : " + isReplica);
					if(!isReplica) {
						Log.i(TAG, "Forwarding insert to " + nextNode);
						new ClientTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, "replicate#"+filename+"#"+string+"#1", nextNode*2);
					}
					isReplica = false;
					threadAccess.release();
				} catch (IOException ioe) {
					Log.e("TextEntryState", "Couldn't open file for output: " + ioe);
				} catch (Exception e) {
					Log.e(TAG, "File write failed");
				}
			}
		} else {
			// forward
			Log.i(TAG, "insert forwarded to " + nextNode);
			new ClientTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, "insert#"+filename+"#"+string, nextNode*2);
		}

		Log.v("insert", values.toString());
		return uri;
	}

	@Override
	public boolean onCreate() {
		// TODO Auto-generated method stub
		context = getContext();
		threadAccess = new Semaphore(1, true);

		Uri.Builder uriBuilder = new Uri.Builder();
		uriBuilder.authority("edu.buffalo.cse.cse486586.simpledht.provider");
		uriBuilder.scheme("content");
		myUri = uriBuilder.build();

		TelephonyManager tel = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
		String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
		myPort = Integer.parseInt(portStr);
		queryInitiatorPort = myPort;
		try {
			myhash = genHash(Integer.toString(myPort));

		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}

		ServerSocket serverSocket = null;
		try {
			serverSocket = new ServerSocket(SERVER_PORT);
			new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, serverSocket);
		} catch (IOException e) {
			e.printStackTrace();
		}

		int i = 5554;
		while (i < 5564) {
			try {
				String hashKey = genHash(Integer.toString(i));
				hashPortMap.put(hashKey, i);
				hashKeyList.add(hashKey);
			} catch (NoSuchAlgorithmException e) {
				e.printStackTrace();
			}
			i += 2;
		}
		Collections.sort(hashKeyList);
		for(String hashkey: hashKeyList) {
			orderedPorts.add(hashPortMap.get(hashkey));
		}
		int myhashindex = hashKeyList.indexOf(myhash);
		if(myhashindex == 0) {
			prevhash = hashKeyList.get(hashKeyList.size()-1);
			prevNode = hashPortMap.get(prevhash);
		} else {
			prevhash = hashKeyList.get(myhashindex-1);
			prevNode = hashPortMap.get(prevhash);
		}
		if(myhashindex == hashKeyList.size()-1) {
			nexthash = hashKeyList.get(0);
			nextNode = hashPortMap.get(nexthash);
		} else {
			nexthash = hashKeyList.get(myhashindex+1);
			nextNode = hashPortMap.get(nexthash);
		}
		return false;
	}

	@Override
	public Cursor query(Uri uri, String[] projection, String selection,
			String[] selectionArgs, String sortOrder) {
		// TODO Auto-generated method stub
		String filename = selection;
		FileInputStream inputStream = null;
		String hashedKey = null;

		try {
			hashedKey = genHash(filename);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		MatrixCursor cursor = new MatrixCursor(
				new String[] {"key", "value"}, 5
		);

		if(filename.equals("@")) {
			// return all local key values
			synchronized (filename) {
				String[] listKeys = context.fileList();
				try {
					threadAccess.acquire();
					InputStreamReader inputStreamReader = null;
					BufferedReader bufferedReader = null;
					for (String key : listKeys) {
						inputStream = context.openFileInput(key);
						inputStreamReader = new InputStreamReader(inputStream);
						bufferedReader = new BufferedReader(inputStreamReader);
						String line = bufferedReader.readLine();
						cursor.addRow(new String[]{key, line});
					}
					inputStreamReader.close();
					inputStream.close();
					bufferedReader.close();
					threadAccess.release();
				} catch (Exception e) {
					Log.e(TAG, "Error reading all local files " + e);
				}
			}
		} else if(filename.equals("*")) {
			try {
				String resp = new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, "query1#*#"+queryInitiatorPort, nextNode*2).get();
				cursor = (MatrixCursor) query(myUri, null, "@", null, null);
				Log.i(TAG, "Query: remote data obtained " + resp);
				String[] clientKeyvalues = {};
				if(resp != "" && resp != null) {
					clientKeyvalues = resp.split(",");
				}
				for(String keyval: clientKeyvalues) {
					if(keyval.isEmpty()) {
						continue;
					}
					String[] keyvalueArr = keyval.split("#");
					cursor.addRow(keyvalueArr);
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			} catch (ExecutionException e) {
				e.printStackTrace();
			}

		} else if ((prevNode == myPort && nextNode == myPort) || (hashedKey.compareTo(myhash) < 0 && hashedKey.compareTo(prevhash) >= 0) || (prevhash.compareTo(myhash) > 0 && nexthash.compareTo(myhash) > 0 && (hashedKey.compareTo(prevhash) >= 0 || hashedKey.compareTo(myhash) < 0))) {

			synchronized (filename) {
				try {
					threadAccess.acquire();
					inputStream = context.openFileInput(filename);
					InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
					BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
					StringBuilder sb = new StringBuilder();
					String line = bufferedReader.readLine();
					Log.i(TAG, "Value read: " + line);
					sb.append(line);
					cursor.addRow(new String[] {filename, line});

					inputStreamReader.close();
					inputStream.close();
					bufferedReader.close();
					threadAccess.release();
				} catch (Exception e) {
					Log.e(TAG, "File read failed");
				}
			}
		} else {
			Log.i(TAG, "Query: needs to be forwarded to " + nextNode);
			try {
				String resp = new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, "query1#" + filename + "#" + queryInitiatorPort, nextNode*2).get();
				synchronized (resp) {
					Log.i(TAG, "Query: response from " + nextNode + " resp " + resp);
					String[] clientKeyvalues = {};
					if(resp != "" && resp != null) {
						clientKeyvalues  = resp.split(",");
					}
					for(String keyval: clientKeyvalues) {
						if(keyval.isEmpty()) {
							continue;
						}
						String[] keyvalueArr = keyval.split("#");
						cursor.addRow(keyvalueArr);
					}
				}

			} catch (InterruptedException e) {
				e.printStackTrace();
			} catch (ExecutionException e) {
				e.printStackTrace();
			}
		}

		return cursor;
	}

	@Override
	public int update(Uri uri, ContentValues values, String selection,
			String[] selectionArgs) {
		// TODO Auto-generated method stub
		return 0;
	}

    private synchronized String genHash(String input) throws NoSuchAlgorithmException {
        MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
        byte[] sha1Hash = sha1.digest(input.getBytes());
        Formatter formatter = new Formatter();
        for (byte b : sha1Hash) {
            formatter.format("%02x", b);
        }
        return formatter.toString();
    }

	private class ClientTask extends AsyncTask<Object, Void, String> {

		@Override
		protected String doInBackground(Object... params) {
			String msg = (String) params[0];
			int remotePort = (Integer) params[1];
			try {
				Socket socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
						remotePort);
				DataOutputStream dataOutputStream = new DataOutputStream(socket.getOutputStream());
				dataOutputStream.writeUTF(msg);
				dataOutputStream.flush();
				if(msg.contains("query1")) {
					DataInputStream dataInputStream = new DataInputStream((socket.getInputStream()));
					String resp = dataInputStream.readUTF();
					Log.i(TAG, "Client Task resp: " + resp);
					if (resp.equals("OK")) {
						socket.close();
					} else {
						socket.close();
						return resp;
					}
				}
			} catch (UnknownHostException e) {
				Log.e(TAG, "ClientTask UnknownHostException");
			} catch (IOException e) {
				Log.e(TAG, "ClientTask socket IOException");
				Log.e(TAG, e.getMessage());
			}

			return null;
		}
	}

	private class ServerTask extends AsyncTask<ServerSocket, String, Void> {

		@Override
		protected Void doInBackground(ServerSocket... sockets) {
			ServerSocket serverSocket = sockets[0];

			String line = "";
			try {
				while(true) {
					Socket socket = serverSocket.accept();
					DataInputStream inputMsg = new DataInputStream(socket.getInputStream());
					DataOutputStream dataOutputStream = new DataOutputStream(socket.getOutputStream());
					String msg = "";
					StringBuffer evaluationMsg;
					if(inputMsg != null)
						msg = inputMsg.readUTF();
					//Log.i(TAG, "Server Task: " + msg);
					if(msg.contains("query1")) {
						String query = msg.split("#")[1];
						Log.i(TAG, "forwarded query received " + query);
						queryInitiatorPort = new Integer(msg.split("#")[2]);
						Log.i(TAG, "forwarded query: queryInitiatorPort " + queryInitiatorPort);
						String allKVs = "";
						Log.i(TAG, "forwarded query: myport " + myPort);

						if (queryInitiatorPort != myPort) {
							Cursor qResult = query(myUri, null, query, null, null);
							// To do: process cursor and respond with arraylist
							qResult.moveToFirst();

							while (!qResult.isAfterLast()) {
								String key = qResult.getString(qResult.getColumnIndex("key"));
								String value = qResult.getString(qResult.getColumnIndex("value"));
								allKVs += key+ "#" + value + ",";
								qResult.moveToNext();
							}
							qResult.close();
						}
						queryInitiatorPort = myPort;
						dataOutputStream.writeUTF(allKVs);
						dataOutputStream.flush();
					} else {
						if(msg.contains("#")) {
							dataOutputStream.writeUTF("OK");
							dataOutputStream.flush();
							publishProgress(msg);
						}
					}
				}
			} catch (IOException e) {
				e.printStackTrace();
			}

			return null;
		}

		private Uri buildUri(String scheme, String authority) {
			Uri.Builder uriBuilder = new Uri.Builder();
			uriBuilder.authority(authority);
			uriBuilder.scheme(scheme);
			return uriBuilder.build();
		}

		protected void onProgressUpdate(String...strings) {
			Uri mUri = buildUri("content", "edu.buffalo.cse.cse486586.groupmessenger1.provider");
			ContentValues cv = new ContentValues();

			String strReceived = strings[0];
			if(strReceived.contains("next")) {
				String nextPortStr = strReceived.split("#")[1];
				nextNode = new Integer(nextPortStr);
				try {
					nexthash = genHash(nextPortStr);
				} catch (NoSuchAlgorithmException e) {
					e.printStackTrace();
				}
			} else if(strReceived.contains("prev")) {
				String prevPortStr = strReceived.split("#")[1];
				prevNode = new Integer(prevPortStr);
				try {
					prevhash = genHash(prevPortStr);
				} catch (NoSuchAlgorithmException e) {
					e.printStackTrace();
				}
			} else if(strReceived.contains("insert")) {
				String key = strReceived.split("#")[1];
				String value = strReceived.split("#")[2];
				ContentValues cvToInserted = new ContentValues();
				cvToInserted.put("key", key);
				cvToInserted.put("value", value);
				insert(myUri, cvToInserted);
			} else if(strReceived.contains("delete")) {
				String query = strReceived.split("#")[1];
				queryInitiatorPort = new Integer(strReceived.split("#")[2]);
				if(myPort != queryInitiatorPort) {
					delete(myUri, query, null);
				}
			} else if(strReceived.contains("replicatedDelete")) {
				String key = strReceived.split("#")[1];
				int replicaCnt = new Integer(strReceived.split("#")[2]);
				isReplica = true;
				delete(myUri, key, null);
				if(replicaCnt == 1) {
					new ClientTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, "replicatedDelete#"+key+"#2", nextNode*2);
				}
			} else if(strReceived.contains("replicate")) {
				String key = strReceived.split("#")[1];
				String value = strReceived.split("#")[2];
				int replicaCnt = new Integer(strReceived.split("#")[3]);
				ContentValues cvToInserted = new ContentValues();
				cvToInserted.put("key", key);
				cvToInserted.put("value", value);
				isReplica = true;
				insert(myUri, cvToInserted);
				if(replicaCnt == 1) {
					new ClientTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, "replicate#"+key+"#"+value+"#2", nextNode*2);
				}
			}

			return;
		}
	}
}
